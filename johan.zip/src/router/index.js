import { createRouter, createWebHistory } from 'vue-router'
import PaginaGestion from '@/components/PaginaGestion.vue'
import TablaUsuarios from '@/components/TablaUsuarios.vue'
import TablaContacto from '@/components/TablaContacto.vue'
import NotFound from '@/components/NotFound.vue'
import TablaEmpleo from '@/components/TablaEmpleo.vue'
import PoliticaPrivacidad from '@/components/PoliticaPrivacidad.vue'
import AvisosLegales from '@/components/AvisosLegales.vue'
import TablaComentarios from '@/components/TablaComentarios.vue'
import TablaArticulos from '@/components/TablaArticulos.vue'
import TablaRegistro from '@/components/TablaRegistro.vue'
import TablaLogin from '@/components/TablaLogin.vue'
import PaginaInicio from '@/components/PaginaInicio.vue'
import TablaTienda from '@/components/TablaTienda.vue'

const routes = [
  {
    path: '/',
    name: 'PaginaGestion',
    component: PaginaGestion,
    meta: { requiresAdmin: true }
  },
  {
    path: '/inicio',
    name: 'PaginaInicio',
    component: PaginaInicio,
    
  },
  {
    path: '/usuarios',
    name: 'usuarios',
    component: TablaUsuarios,
    meta: { requiresAdmin: true }
  },
  {
    path: '/contacto',
    name: 'contacto',
    component: TablaContacto
  },
  {
    path:'/:pathMatch(.*)*',
    name: 'NotFound',
    component: NotFound
  },
  {
    path: '/empleo',
    name: 'TablaEmpleo',
    component: TablaEmpleo
  },
  {
    path: '/privacidad',
    name: 'PoliticaPrivacidad',
    component: PoliticaPrivacidad
  },
  {
    path: '/avisos-legales',
    name: 'AvisosLegales',
    component: AvisosLegales
  },
  {
    path: '/comentarios',
    name: 'TablaComentarios',
    component: TablaComentarios
  },
  {
    path: '/articulos',
    name: 'TablaArticulos',
    component: TablaArticulos,
    meta: { requiresAdmin: true }
  },
  {
    path: '/tienda',
    name: 'TablaTienda',
    component: TablaTienda
  },
  {
    path: '/registro',
    name: 'TablaRegistro',
    component: TablaRegistro
  },
  {
    path: '/login',
    name: 'login',
    component: TablaLogin
  }
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

// Guardia de navegación global
router.beforeEach((to, from, next) => {
  // Verificar si la ruta requiere administrador
  if (to.meta.requiresAdmin) {
    // Verifica si el usuario está logueado y si es admin
    const isLogueado = localStorage.getItem('isLogueado') === 'true';
    const isAdmin = localStorage.getItem('isAdmin') === 'true';

    if (!isLogueado || !isAdmin) {
      // Si no es admin, redirige a otra ruta (ejemplo: login)
      next({ name: 'login' });
    } else {
      next(); // Permite el acceso a la ruta
    }
  } else {
    next(); // Si no es necesaria la verificación de admin, permite el acceso
  }
});

export default router;
