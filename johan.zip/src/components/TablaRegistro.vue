<template>
  <div class="">
    <h3 class="text-center front-weight-bold mt-4 text-primary" id="titulo"><i class="bi-people blue"></i> REGISTRO
      <router-link to="/" class="text-dark"><button class="btn btn-customb"><i
            class="bi bi-arrow-return-left"></i></button></router-link>
    </h3>
  </div>
  <br>
  <div class="container-fluid border p-4">
    <form class="form-in-line">
      <div class="col-10 col-m-6 col-lg-8 mx-auto">
        <div class="input-group-text mb-3">
          <span class="input-group-text custom-span me-2">DNI/NIE:</span>
          <input type="text" class="form-control sm w-25 text-center" placeholder="DNI-NIE" v-model="usuario.dni"
            @blur="validarDNI(this.usuario.dni)" :disabled="editDni">
        </div>
        <div class="input-group-text mb-3">
          <span class="input-group-text custom-span me-2">Apellidos: </span>
          <input type="text" class="form-control sm w-50" placeholder="Apellidos" v-model="usuario.apellidos">
          <span class="input-group-text custom-span ms-2 me-2">Nombre: </span>
          <input type="text" class="form-control sm w-50" placeholder="Nombre" v-model="usuario.nombre">
        </div>
        <div class="input-group-text mb-3">
          <span class="input-group-text custom-span ms-2 me-2">Email: </span>
          <input type="email" class="form-control sm w-50" placeholder="Email" v-model="usuario.email"
            @blur="validarEmail(this.usuario.email)">
          <span class="input-group-text custom-span ms-2 me-2">Repita Email: </span>
          <input type="email" class="form-control sm w-50" placeholder="Repita su Email" v-model="emailRepetido"
            @blur="comprobarEmail(this.usuario.email, this.emailRepetido)">

          <span class="input-group-text custom-span ms-2 me-2">Móvil:</span>
          <input class="form-control sm w-25 text-center" type="text" placeholder="Móvil" v-model="usuario.telefono"
            @blur="validarTelefono(this.usuario.telefono)">
        </div>

        <div class="input-group-text mb-3">
          <span class="input-group-text custom-span ms-2 me-2">Contraseña: </span>
          <input type="password" class="form-control sm w-50" :class="{ 'error-border': passMissmatch }"
            placeholder="Contraseña" v-model="usuario.pass">
          <span class="input-group-text custom-span ms-2 me-2">Repetir contraseña: </span>
          <input type="password" class="form-control sm w-50" :class="{ 'error-border': passMissmatch }"
            placeholder="Repita su contraseña" v-model="pass2">
        </div>

        <div class="input-group-text mb-3">
          <span class="input-group-text custom-span me-2">Dirección: </span>
          <input type="text" class="form-control sm w-75" placeholder="Dirección" v-model="usuario.direccion">
        </div>

        <div class="input-group-text mb-3">
          <span class="input-group-text custom-span me-2 ms-2">Provincia: </span>
          <select name="provincia" class="form-control sm w-25" v-model="usuario.provincia">
            <option value="">Provincia</option>
            <option v-for="provincia in provincias" :key="provincia.id" :value="provincia">
              {{ provincia.nm }}
            </option>
          </select>
          <span class="input-group-text custom-span ms-2 me-2">Municipio: </span>
          <select name="municipio" class="form-control sm w-50" v-model="usuario.municipio">
            <option value="">Municipio</option>
            <option v-for="municipio in municipiosFiltrados" :key="municipio.id" :value="municipio">
              {{ municipio.nm }}
            </option>
          </select>

          <button class="btn btn-light m-1" @click="limpiarFormCli()">
            <i class="bi-arrow-counterclockwise"></i>
          </button>

        </div>
      </div>
      <div class="d-flex justify-content-center">
        <input type="checkbox" name="lopd" id="lopd" v-model="lopd"><label for="lopd" class="mx-2"> He
          leído y acepto las
          <router-link to="/privacidad" exact-active-class="active">Políticas de Privacidad</router-link></label>
      </div>
      <button class="btn btn-primary m-1" @click.prevent="grabarUsuario">Enviar</button>
    </form>
  </div>
</template>

<script>
import Swal from 'sweetalert2';
import { encriptarContrasena } from '@/config/passport.mjs';

export default {
  name: "TablaUsuarios",
  components: {
  },

  data() {
    return {

      usuario: {
        dni: '',
        alta: '',
        apellidos: '',
        nombre: '',
        direccion: '',
        email: '',
        provincia: '',
        municipio: '',
        baja: '',
        telefono: '',
        tipo: 'usuario',
        pass: ''
      },

      pass2: '',
      emailRepetido: '',
      provincias: [],
      municipios: [],
      errores: [],
      currentPage: 1,
      pageSize: 5,
      isChecked: false,
    };
  },

  mounted() {
    this.getProvincias();
    this.getMunicipios();
  },


  computed: {
    passMissmatch() {
      return this.usuario.pass !== this.pass2
    },

    municipiosFiltrados() {
      if (!this.usuario.provincia || !this.usuario.provincia.id) return [];

      return this.municipios.filter(municipio =>
        municipio.id.startsWith(this.usuario.provincia.id)
      )
    },
  },

  methods: {
    limpiarFormCli() {
      this.usuario = {
        dni: '',
        alta: '',
        apellidos: '',
        nombre: '',
        direccion: '',
        email: '',
        provincia: '',
        municipio: '',
        baja: '',
        telefono: '',
      },
        this.lopd = false,
        this.emailRepetido = ''
    },

    validarDNI(dni) {
      if (dni === '') {
        // Si el campo está vacío, no hace nada
        return true;
      }
      dni = dni.toUpperCase(); // Convertir a mayúsculas
      this.usuario.dni = dni;
      // Comprobar el formato del DNI/NIE
      const dniRegex = /^[XYZ0-9][0-9]{7}[A-Z]$/; // Formato 8 dígitos seguido de 1 letra

      if (!dniRegex.test(dni)) {
        this.mostrarAlerta('Error', 'El NIE/DNI con formato no válido.', 'error');
        return false;
      }

      // Inicializar variables para el cálculo
      let dniNum = dni.substring(0, 8); // Extraer los númerhttp://localhost:3000/provinciasos
      const letra = dni.charAt(8); // Obtener la letra en la posición 8
      // Identificación del NIE y sustitución
      if (dniNum.charAt(0) === 'X') {
        dniNum = dniNum.substring(1, 8)
        dniNum = '0' + dniNum; // Sustituir X por 0
      } else if (dniNum.charAt(0) === 'Y') {
        dniNum = dniNum.substring(1, 8)
        dniNum = '1' + dniNum; // Sustituir Y por 1
      } else if (dni.charAt(0) === 'Z') {
        dniNum = dniNum.substring(1, 8)
        dniNum = '2' + dniNum; // Sustituir Z por 2
      }

      // Comprobar la letra esperada
      const letras = 'TRWAGMYFPDXBNJZSQVHLCKE'; // Letras válidas para el DNI
      const letraCalculada = letras[dniNum % 23]; // Calcular la letra esperada
      if (letra !== letraCalculada) {
        this.mostrarAlerta('Error', 'DNI/NIE Incorrecto.', 'error');
        return false;
      }

      return true; // DNI/NIE válido

    },

    validarTelefono(telefono) {
      if (telefono == '') {
        this.mostrarAlerta('Error', 'El teléfono con formato no valido', 'error');
      }
      const regex = /^[67]\d{8}$/;
      if (!regex.test(telefono)) {
        this.mostrarAlerta('Error', 'El teléfono con formato no valido', 'error')
      }
    },

    validarEmail(email) {
      if (email == '') {
        this.mostrarAlerta('Error', 'El email con formato no valido', 'error');
      }
      const regex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
      if (!regex.test(email)) {
        this.mostrarAlerta('Error', 'El email con formato no valido', 'error')
      }
    },

    async getProvincias() {
      try {
        const response = await fetch('http://localhost:3000/provincias');
        if (!response.ok) {
          throw new Error('Error en la solicitud:' + response.statusText);
        }
        this.provincias = await response.json();
      } catch (error) {
        console.error(error);
      }
    },

    async getMunicipios() {
      try {
        const response = await fetch('http://localhost:3000/municipios');
        if (!response.ok) {
          throw new Error('Error en la solicitud:' + response.statusText);
        }
        this.municipios = await response.json();
      } catch (error) {
        console.error(error);
      }
    },

    mostrarAlerta(titulo, mensaje, icono) {
      Swal.fire({
        title: titulo,
        text: mensaje,
        icon: icono,
        customClass: {
          container: 'custom-alert-container',
          popup: 'custom-alert-popup',
          modal: 'custom-alert-modal'
        }
      })
    },

    comprobarEmail(email1, email2) {
      if (email1 != email2) {
        this.mostrarAlerta('Error', 'El email no coincide', 'error');
        return true;
      }
    },


    obtenerFechaHoy() {
      const fecha = new Date();
      const opciones = { day: '2-digit', month: '2-digit', year: 'numeric' };
      const fechaFormateada = new Intl.DateTimeFormat('es-ES', opciones).format(fecha);
      //return fecha.toLocaleDateString('es-ES');  // Formato dd/mm/yyyy
      return fechaFormateada;
    },

    async grabarUsuario() {
      const resultado = await Swal.fire({
        title: '¿Deseas registrarte?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Sí',
        cancelButtonText: 'No',
        cancelButtonColor: '#d33',
        confirmButtonColor: '#3085d6',
      })

      if (resultado.isConfirmed) {
        if (this.lopd == true) {
          this.usuario.alta = this.obtenerFechaHoy()
          // Verificar si los campos requeridos están llenos
          if (this.usuario.dni && this.usuario.apellidos && this.usuario.telefono && this.usuario.alta && this.usuario.nombre && this.usuario.direccion &&
            this.usuario.email && this.usuario.provincia && this.usuario.municipio) {
            try {
              if (this.comprobarEmail(this.usuario.email, this.emailRepetido)) {
                this.mostrarAlerta('Error', 'El email no coincide', 'error');
              } else if (this.usuario.pass !== this.pass2) {
                this.mostrarAlerta('Error', 'La contraseña no coincide', 'error');
              } else {
                const contrasena = await encriptarContrasena(this.usuario.pass)
                this.usuario.pass =  contrasena;
                this.usuario.baja = '';

                const response = await fetch('http://localhost:3000/usuarios');
                if (!response.ok) {
                  throw new Error('Error al obtener los usuarios: ' + response.statusText);
                }

                const usuariosExistentes = await response.json();

                const usuarioExistente = usuariosExistentes.find(usuario => usuario.dni === this.usuario.dni);

                if (usuarioExistente && usuarioExistente.baja === '') {
                  this.mostrarAlerta('Error', 'Ese DNI ya está registrado', 'error');
                } else if (usuarioExistente) {
                  this.mostrarAlerta('Error', 'Habla con nuestro servicio al cliente para recuperar tu cuenta', 'error');
                } else {
                  const crearResponse = await fetch('http://localhost:3000/usuarios', {
                    method: 'POST',
                    headers: {
                      'Content-Type': 'application/json', 
                    },
                    body: JSON.stringify(this.usuario),
                  });

                  this.mostrarAlerta('Registro correcto', 'Ya has completado el registro', 'success')
                  this.limpiarFormCli();


                  if (!crearResponse.ok) {
                    throw new Error('Error al registrar el usuario: ' + crearResponse.statusText);
                  }
                }
              }
            } catch (error) {
              console.error(error);
              this.mostrarAlerta('Error', 'No se pudo completar el registro', 'error');
            }
          } else {
            this.mostrarAlerta('Error', 'Por favor, completa todos los campos requeridos.', 'error');
          }
        } else {
          this.mostrarAlerta('Error', 'Por favor, acepta las politicas de privacidad.', 'error');
        }
      }
    },
  },
}

</script>

<style scoped>
.custom-date-input {
  width: 12em;
  text-align: center;
}
</style>