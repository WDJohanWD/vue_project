<template>
    <h1>Bienvenido a la página de inicio</h1>
</template>

<script>
export default {
    name: "PaginaInicio"
}
</script>

<style>
</style>