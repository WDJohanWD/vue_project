<template>
    <div id="navbar">
        <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
            <div class="container-fluid">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                    aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item" v-if="isAdmin">
                            <router-link to="/"  class="nav-link text-white"
                                exact-active-class="active">Página de Gestión</router-link>
                        </li>
                        <li class="nav-item">
                            <router-link to="/inicio"  class="nav-link text-white"
                                exact-active-class="active">Página de Inicio</router-link>
                        </li>
                        <li class="nav-item" v-if="isAdmin">
                            <router-link to="/usuarios" class="nav-link text-white"
                                exact-active-class="active">Usuarios</router-link>
                        </li>
                        <li class="nav-item">
                            <router-link to="/empleo" class="nav-link text-white"
                                exact-active-class="active">Empleo</router-link>
                        </li>
                        <li class="nav-item">
                            <router-link to="/comentarios" class="nav-link text-white"
                                exact-active-class="active">Comentarios</router-link>
                        </li>
                        <li class="nav-item">
                            <router-link to="/articulos" class="nav-link text-white"
                                exact-active-class="active">Articulos</router-link>
                        </li>
                        <li class="nav-item">
                            <router-link to="/tienda" class="nav-link text-white"
                                exact-active-class="active">Tienda</router-link>
                        </li>
                        <li class="nav-item">
                            <router-link to="/contacto" class="nav-link text-white"
                                exact-active-class="active">Contacto</router-link>
                        </li>
                    </ul>
                    <input class="form-control me-1 w-25 ms-auto" type="search" placeholder="Buscar"
                        aria-label="Search">
                    <button class="btn btn-outline-success bg-light" type="submit">
                        <i class="bi bi-search"></i></button>
                    
                    <h2 class="text-white ms-5 fs-5 mb-0" v-if="isLogueado" >{{ nombreUsuario }}</h2>
                    
                    <div class="dropdown">
                        <button class="btn btn-blue dropdown-toggle text-white ms-4" type="button"
                            id="dropdownMenuButton" data-bs-toggle="dropdown" aria-haspopup="true"
                            aria-expanded="false" @click="toogleDropdown">
                            <i class="bi bi-person-circle fa-2x"></i>
                        </button>

                        <ul class="dropdown-menu dropdown-menu-end" :class="{show: isDropdownVisible}" aria-labelledby="dropdownMenuButton">
                            <li><a class="dropdown-item" href="/login" v-if="!isLogueado">Acceso</a></li>
                            <li><a class="dropdown-item" href="/registro" v-if="!isLogueado">Registro</a></li>
                            <li><a class="dropdown-item" href="#" @click="logout" v-if="isLogueado">Cerrar Sesión</a></li>
                        </ul>
                    </div>

                </div>
            </div>
        </nav>
    </div>
    <router-view />
</template>

<script>
export default {
    name: "NavBar",
    data(){
        return{
            isDropdownVisible: false,
            isAdmin: false,
            isLogueado: false,
            usuarios: [],
            nombreUsuario: ""
        }
    },

    mounted() {
        this.isLogueado = localStorage.getItem('isLogueado') === 'true'
        this.isAdmin = localStorage.getItem('isAdmin') === 'true'
        this.getUsuarios();

    },

    methods:{
        async getUsuarios() {
            try {
            const response = await fetch('http://localhost:3000/usuarios');
            if (!response.ok) {
                throw new Error('Error en la solicitud: ' + response.statusText);
            }

            // Obtener y ordenar usuarios por apellidos y luego por nombre
            this.usuarios = (await response.json()).sort((a, b) =>
                a.apellidos.localeCompare(b.apellidos) || a.nombre.localeCompare(b.nombre)
            );

            const dniUsuario = localStorage.getItem('dniUsuario');
            const usuario = this.usuarios.find((user) => user.dni === dniUsuario);
            if (usuario) {
                this.nombreUsuario = `${usuario.nombre}`;
            }

            } catch (error) {
            console.error(error);
            }
        },

        toogleDropdown(){
            console.log("Botón pulsado")
            this.isDropdownVisible = !this.isDropdownVisible
        },

        logout(){
            localStorage.removeItem('isLogueado')
            localStorage.removeItem('isAdmin')
            localStorage.removeItem('dniUsuario')

            this.$router.push({name: 'login'}).then(() => {
                window.location.reload()
            })
        },
    }
}
</script>

<style scoped>
/* Cambiar el color de la clase active */
.nav-link.active {
    color: #FAD02E !important;
    font-size: 1.1rem;
    /* Aumenta un poco el tamaño de la fuente */
    transition: font-size 0.5s ease;
    /* con una transición suave */
}

.dropdown-menu {
    left: auto;
    right: 0;
}
</style>