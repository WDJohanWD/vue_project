<template>
    <h3 class="text-center front-weight-bold mt-4 text-primary" id="titulo"><i class="bi bi-wrench-adjustable blue"></i> PANEL DE GESTIÓN</h3>

    <div class="grid-box">
        <div class="my-3">
            <router-link to="/usuarios" class="text-white text-decoration-none" exact-active-class="active"><button class="btn btn-primary mx-4 w-25">Gestión de usuarios</button></router-link>
            <router-link to="/empleo" class="text-white text-decoration-none" exact-active-class="active"><button class="btn btn-primary mx-4 w-25">Gestión de candidatos</button></router-link>
        </div>
        <div class="my-3">
            <router-link to="/comentarios" class="text-white text-decoration-none" exact-active-class="active"><button class="btn btn-primary mx-4 w-25">Comentarios</button></router-link>
            <router-link to="/articulos" class="text-white text-decoration-none" exact-active-class="active"><button class="btn btn-primary mx-4 w-25">Articulos</button></router-link>
        </div>
        <div class="my-3">
            <router-link to="/" class="text-white text-decoration-none" exact-active-class="active"><button class="btn btn-dark mx-4 w-25" disabled>En construcción</button></router-link>
            <router-link to="/" class="text-white text-decoration-none" exact-active-class="active"><button class="btn btn-dark mx-4 w-25" disabled>En construcción</button></router-link>
        </div>
    </div>
</template>

<script>

export default {
    name: "PaginaGestion",
    components: {
    }
}
</script>

<style>

</style>