<template>
    <div class="container my-5">  
          <div class="container my-2">
              <div class="table-responsive">
                  <table class="table table-striped">
                      <thead class="table-info rounded-header">
                          <tr class="align-middle">
                              <th scope="col" class="col-md-1">ID</th>
                              <th scope="col" class="col-md-2">Nombre</th>
                              <th scope="col" class="col-md-2">Categoria</th>
                              <th scope="col" class="col-md-4">Descripción</th>
                              <th scope="col" class="col-md-2">Precio</th>
                              <th scope="col" class="col-md-4" v-if="isAdmin">Stock</th>
                              <th scope="col" class="pale-yellow table-warning col-md-4">Añadir al carro</th>
                          </tr>
                      </thead>
                      <tbody>
                          <tr v-for="articulo in articulos" :key="articulo.id">
                              <td class="align-middle">{{ acortarId(articulo._id) }}</td>
                              <td class="align-middle">{{ articulo.nombre }}</td>
                              <td class="align-middle">{{ articulo.categoria }}</td>
                              <td class="align-middle">{{ articulo.descripcion }}</td>
                              <td class="align-middle">{{ articulo.precio_unitario }}</td>
                              <td class="align-middle" v-if="isAdmin">{{ articulo.stock_disponible }}</td>
  
                              <td class="text-center align-middle pale-yellow table-warning">
                                  <div>
                                      <button class="btn btn-success m-2">
                                          <i class="bi bi-cart2"></i>
                                      </button>
                                  </div>
                              </td>
                          </tr>
                      </tbody>
                  </table>
                  <div class="d-flex justify-content-center my-3">
                      <button class="btn btn-primary" :disabled="currentPage === 1" @click="paginaAnterior">
                          <i class="bi bi-chevron-left"> </i>
                      </button>
                      <span class="mx-3 align-self-center">Página {{ currentPage }}</span>
  
                      <button class="btn btn-primary" :disabled="currentPage * pageSize >= articulos.length"
                          @click="siguientePagina">
                          <i class="bi bi-chevron-right"></i>
                      </button>
                  </div>
              </div>
          </div>
      </div>
  </template>
  
  <script>
  //import Swal from 'sweetalert2';
  import { obtenerArticulos } from '@/js/articuloServicios.js';
  
  export default {
      name: "TablaTienda",
      components:{},
  
      data(){
          return{
              articulos: [],
              isAdmin: false,
              isLogueado: false,
              usuarioDni: '',
          }
          
      },
  
      mounted() {
          this.obtenerArt();
          this.isAdmin = localStorage.getItem('isAdmin') === 'true';
          this.isLogueado = localStorage.getItem('isLogueado') === 'true';
          this.usuarioDni = localStorage.getItem('usuarioDni');
      },
  
      methods: {
          async obtenerArt() {
              try {
                  this.articulos = await obtenerArticulos();
              } catch (error) {
                  console.error('Error al obtener los artículos', error);
              }
          },
  
          acortarId(id) {
              return id.slice(-4);
          },
  
          acortarFecha(fecha) {
              return fecha.slice(0, 10);
          }
  
      }
  }
  </script>
  
  <style>
  
  </style>