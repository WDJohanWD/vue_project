import { createRouter, createWebHistory } from 'vue-router'
import PaginaInicio  from '@/components/PaginaInicio.vue'
import TablaUsuarios from '@/components/TablaUsuarios.vue'
import TablaContacto from '@/components/TablaContacto.vue'
import TablaEmpleo    from '@/components/TablaEmpleo.vue'
import NotFound from '@/components/NotFound.vue'
import AvisoLegal from '@/components/AvisoLegal.vue'
import PoliticaPrivacidad from '@/components/PoliticaPrivacidad.vue'
import TablaComentarios from '@/components/TablaComentarios.vue'
import TablaArticulos from '@/components/TablaArticulos.vue'
import TablaRegistro from '@/components/TablaRegistro.vue'
import TablaLogin from '@/components/TablaLogin.vue'


const routes = [
  {
    path: '/',
    name: 'inicio',
    component: PaginaInicio,
    meta: {requiresAdmin: true}
  },
  {
    path: '/usuarios',
    name: 'usuarios',
    component: TablaUsuarios
  }, 
  {
    path: '/contacto',
    name: 'contacto',
    component: TablaContacto
  },
  {
    path: '/:pathMatch(.*)*',
    name:'NotFound',
    component: NotFound
  },
  {
    path: '/empleo',
    name: 'empleo',
    component: TablaEmpleo
  },
  {
    path: '/avisolegal',
    name: 'avisolegal',
    component: AvisoLegal
  },
  {
    path: '/privacidad',
    name: 'privacidad',
    component: PoliticaPrivacidad
  },

  {
    path:'/comentarios',
    name:'comentarios',
    component: TablaComentarios
  },
  {
    path: '/articulos',
    name: 'articulos',
    component: TablaArticulos
  },
  {
    path:'/registro',
    name:'registro',
    component: TablaRegistro
  },
  {
    path: '/login',
    name: 'login',
    component: TablaLogin
  }
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
});

// Guardia de navegación global
router.beforeEach((to, from, next) => {
  // Verificar si la ruta requiere administrador
  if (to.meta.requiresAdmin) {
    // Verifica si el usuario está logueado y si es admin
    const isLogueado = localStorage.getItem('isLogueado') === 'true';
    const isAdmin = localStorage.getItem('isAdmin') === 'true';

    console.log('isLogueado:', isLogueado);
    console.log('isAdmin:', isAdmin);

    if (!isLogueado || !isAdmin) {
      // Si no es admin, redirige a otra ruta (ejemplo: login)
      next({ name: 'login' });
    } else {
      next(); // Permite el acceso a la ruta
    }
  } else {
    next(); // Si no es necesaria la verificación de admin, permite el acceso
  }
});

export default router;

